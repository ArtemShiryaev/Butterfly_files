#!/bin/bash

sudo ifconfig enx689e198e8373 down
sudo ifconfig enx689e198e8373 192.168.7.1
sudo ifconfig enx689e198e8373 up