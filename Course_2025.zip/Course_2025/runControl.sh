#!/bin/bash

sudo ./build/controller -c configs/config.json
